
1. github case: https://github.com/udacity/CarND-MPC-Project/blob/master/install_Ipopt_CppAD.md

2. install need libraries as instucted

3. if any library file is missed or directory issue, try to find the file first, then run
	
	-cd directory of the library firle  $sudo cp library_file /usr/local/lib
	-cd /usr/local/lib  $sudo ldconfigure
